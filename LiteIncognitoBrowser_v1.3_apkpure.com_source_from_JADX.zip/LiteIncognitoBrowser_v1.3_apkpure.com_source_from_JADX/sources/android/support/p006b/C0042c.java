package android.support.p006b;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.p009v4.p010a.C0220g;
import android.support.p009v4.p011b.C0281a;
import java.util.ArrayList;

/* renamed from: android.support.b.c */
public final class C0042c {

    /* renamed from: a */
    public final Intent f66a;

    /* renamed from: b */
    public final Bundle f67b;

    /* renamed from: android.support.b.c$a */
    public static final class C0044a {

        /* renamed from: a */
        private final Intent f68a;

        /* renamed from: b */
        private ArrayList<Bundle> f69b;

        /* renamed from: c */
        private Bundle f70c;

        /* renamed from: d */
        private ArrayList<Bundle> f71d;

        /* renamed from: e */
        private boolean f72e;

        public C0044a() {
            this((C0047e) null);
        }

        public C0044a(C0047e eVar) {
            this.f68a = new Intent("android.intent.action.VIEW");
            IBinder iBinder = null;
            this.f69b = null;
            this.f70c = null;
            this.f71d = null;
            this.f72e = true;
            if (eVar != null) {
                this.f68a.setPackage(eVar.mo73b().getPackageName());
            }
            Bundle bundle = new Bundle();
            C0220g.m803a(bundle, "android.support.customtabs.extra.SESSION", eVar != null ? eVar.mo71a() : iBinder);
            this.f68a.putExtras(bundle);
        }

        /* renamed from: a */
        public C0042c mo68a() {
            if (this.f69b != null) {
                this.f68a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", this.f69b);
            }
            if (this.f71d != null) {
                this.f68a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", this.f71d);
            }
            this.f68a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.f72e);
            return new C0042c(this.f68a, this.f70c);
        }
    }

    private C0042c(Intent intent, Bundle bundle) {
        this.f66a = intent;
        this.f67b = bundle;
    }

    /* renamed from: a */
    public void mo67a(Context context, Uri uri) {
        this.f66a.setData(uri);
        C0281a.m1299a(context, this.f66a, this.f67b);
    }
}
