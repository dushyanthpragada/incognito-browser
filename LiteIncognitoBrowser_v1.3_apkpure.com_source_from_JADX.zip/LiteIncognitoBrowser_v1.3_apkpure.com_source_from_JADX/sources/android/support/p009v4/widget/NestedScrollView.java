package android.support.p009v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p009v4.p020h.C0390b;
import android.support.p009v4.p020h.C0413j;
import android.support.p009v4.p020h.C0414k;
import android.support.p009v4.p020h.C0415l;
import android.support.p009v4.p020h.C0417n;
import android.support.p009v4.p020h.C0421r;
import android.support.p009v4.p020h.p021a.C0383b;
import android.support.p009v4.p020h.p021a.C0389d;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import java.util.ArrayList;

/* renamed from: android.support.v4.widget.NestedScrollView */
public class NestedScrollView extends FrameLayout implements C0413j, C0415l {

    /* renamed from: w */
    private static final C0489a f1247w = new C0489a();

    /* renamed from: x */
    private static final int[] f1248x = {16843130};

    /* renamed from: A */
    private float f1249A;

    /* renamed from: B */
    private C0490b f1250B;

    /* renamed from: a */
    private long f1251a;

    /* renamed from: b */
    private final Rect f1252b;

    /* renamed from: c */
    private OverScroller f1253c;

    /* renamed from: d */
    private EdgeEffect f1254d;

    /* renamed from: e */
    private EdgeEffect f1255e;

    /* renamed from: f */
    private int f1256f;

    /* renamed from: g */
    private boolean f1257g;

    /* renamed from: h */
    private boolean f1258h;

    /* renamed from: i */
    private View f1259i;

    /* renamed from: j */
    private boolean f1260j;

    /* renamed from: k */
    private VelocityTracker f1261k;

    /* renamed from: l */
    private boolean f1262l;

    /* renamed from: m */
    private boolean f1263m;

    /* renamed from: n */
    private int f1264n;

    /* renamed from: o */
    private int f1265o;

    /* renamed from: p */
    private int f1266p;

    /* renamed from: q */
    private int f1267q;

    /* renamed from: r */
    private final int[] f1268r;

    /* renamed from: s */
    private final int[] f1269s;

    /* renamed from: t */
    private int f1270t;

    /* renamed from: u */
    private int f1271u;

    /* renamed from: v */
    private C0491c f1272v;

    /* renamed from: y */
    private final C0417n f1273y;

    /* renamed from: z */
    private final C0414k f1274z;

    /* renamed from: android.support.v4.widget.NestedScrollView$a */
    static class C0489a extends C0390b {
        C0489a() {
        }

        /* renamed from: a */
        public void mo246a(View view, C0383b bVar) {
            int scrollRange;
            super.mo246a(view, bVar);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            bVar.mo1486a((CharSequence) ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                bVar.mo1493c(true);
                if (nestedScrollView.getScrollY() > 0) {
                    bVar.mo1484a(8192);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    bVar.mo1484a(4096);
                }
            }
        }

        /* renamed from: a */
        public void mo367a(View view, AccessibilityEvent accessibilityEvent) {
            super.mo367a(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            C0389d.m1665a(accessibilityEvent, nestedScrollView.getScrollX());
            C0389d.m1666b(accessibilityEvent, nestedScrollView.getScrollRange());
        }

        /* renamed from: a */
        public boolean mo1530a(View view, int i, Bundle bundle) {
            if (super.mo1530a(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i == 4096) {
                int min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
                if (min == nestedScrollView.getScrollY()) {
                    return false;
                }
                nestedScrollView.mo1878c(0, min);
                return true;
            } else if (i != 8192) {
                return false;
            } else {
                int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                if (max == nestedScrollView.getScrollY()) {
                    return false;
                }
                nestedScrollView.mo1878c(0, max);
                return true;
            }
        }
    }

    /* renamed from: android.support.v4.widget.NestedScrollView$b */
    public interface C0490b {
        /* renamed from: a */
        void mo1928a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    /* renamed from: android.support.v4.widget.NestedScrollView$c */
    static class C0491c extends View.BaseSavedState {
        public static final Parcelable.Creator<C0491c> CREATOR = new Parcelable.Creator<C0491c>() {
            /* renamed from: a */
            public C0491c createFromParcel(Parcel parcel) {
                return new C0491c(parcel);
            }

            /* renamed from: a */
            public C0491c[] newArray(int i) {
                return new C0491c[i];
            }
        };

        /* renamed from: a */
        public int f1275a;

        C0491c(Parcel parcel) {
            super(parcel);
            this.f1275a = parcel.readInt();
        }

        C0491c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.f1275a + "}";
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f1275a);
        }
    }

    public NestedScrollView(Context context) {
        this(context, (AttributeSet) null);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1252b = new Rect();
        this.f1257g = true;
        this.f1258h = false;
        this.f1259i = null;
        this.f1260j = false;
        this.f1263m = true;
        this.f1267q = -1;
        this.f1268r = new int[2];
        this.f1269s = new int[2];
        m2228a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1248x, i, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f1273y = new C0417n(this);
        this.f1274z = new C0414k(this);
        setNestedScrollingEnabled(true);
        C0421r.m1780a((View) this, (C0390b) f1247w);
    }

    /* renamed from: a */
    private View m2227a(boolean z, int i, int i2) {
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z2 = false;
        for (int i3 = 0; i3 < size; i3++) {
            View view2 = (View) focusables.get(i3);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i < bottom && top < i2) {
                boolean z3 = i < top && bottom < i2;
                if (view == null) {
                    view = view2;
                    z2 = z3;
                } else {
                    boolean z4 = (z && top < view.getTop()) || (!z && bottom > view.getBottom());
                    if (z2) {
                        if (z3) {
                            if (!z4) {
                            }
                        }
                    } else if (z3) {
                        view = view2;
                        z2 = true;
                    } else if (!z4) {
                    }
                    view = view2;
                }
            }
        }
        return view;
    }

    /* renamed from: a */
    private void m2228a() {
        this.f1253c = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f1264n = viewConfiguration.getScaledTouchSlop();
        this.f1265o = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1266p = viewConfiguration.getScaledMaximumFlingVelocity();
    }

    /* renamed from: a */
    private void m2229a(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1267q) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f1256f = (int) motionEvent.getY(i);
            this.f1267q = motionEvent.getPointerId(i);
            if (this.f1261k != null) {
                this.f1261k.clear();
            }
        }
    }

    /* renamed from: a */
    private boolean m2230a(int i, int i2, int i3) {
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = height + scrollY;
        boolean z = false;
        boolean z2 = i == 33;
        View a = m2227a(z2, i2, i3);
        if (a == null) {
            a = this;
        }
        if (i2 < scrollY || i3 > i4) {
            m2244g(z2 ? i2 - scrollY : i3 - i4);
            z = true;
        }
        if (a != findFocus()) {
            a.requestFocus(i);
        }
        return z;
    }

    /* renamed from: a */
    private boolean m2231a(Rect rect, boolean z) {
        int a = mo1865a(rect);
        boolean z2 = a != 0;
        if (z2) {
            if (z) {
                scrollBy(0, a);
                return z2;
            }
            mo1876b(0, a);
        }
        return z2;
    }

    /* renamed from: a */
    private boolean m2232a(View view) {
        return !m2233a(view, 0, getHeight());
    }

    /* renamed from: a */
    private boolean m2233a(View view, int i, int i2) {
        view.getDrawingRect(this.f1252b);
        offsetDescendantRectToMyCoords(view, this.f1252b);
        return this.f1252b.bottom + i >= getScrollY() && this.f1252b.top - i <= getScrollY() + i2;
    }

    /* renamed from: a */
    private static boolean m2234a(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m2234a((View) parent, view2);
    }

    /* renamed from: b */
    private static int m2235b(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    /* renamed from: b */
    private void m2236b(View view) {
        view.getDrawingRect(this.f1252b);
        offsetDescendantRectToMyCoords(view, this.f1252b);
        int a = mo1865a(this.f1252b);
        if (a != 0) {
            scrollBy(0, a);
        }
    }

    /* renamed from: b */
    private boolean m2237b() {
        View childAt = getChildAt(0);
        if (childAt == null) {
            return false;
        }
        return getHeight() < (childAt.getHeight() + getPaddingTop()) + getPaddingBottom();
    }

    /* renamed from: c */
    private void m2238c() {
        if (this.f1261k == null) {
            this.f1261k = VelocityTracker.obtain();
        } else {
            this.f1261k.clear();
        }
    }

    /* renamed from: d */
    private void m2239d() {
        if (this.f1261k == null) {
            this.f1261k = VelocityTracker.obtain();
        }
    }

    /* renamed from: d */
    private boolean m2240d(int i, int i2) {
        if (getChildCount() <= 0) {
            return false;
        }
        int scrollY = getScrollY();
        View childAt = getChildAt(0);
        return i2 >= childAt.getTop() - scrollY && i2 < childAt.getBottom() - scrollY && i >= childAt.getLeft() && i < childAt.getRight();
    }

    /* renamed from: e */
    private void m2241e() {
        if (this.f1261k != null) {
            this.f1261k.recycle();
            this.f1261k = null;
        }
    }

    /* renamed from: f */
    private void m2242f() {
        this.f1260j = false;
        m2241e();
        mo1866a(0);
        if (this.f1254d != null) {
            this.f1254d.onRelease();
            this.f1255e.onRelease();
        }
    }

    /* renamed from: g */
    private void m2243g() {
        if (getOverScrollMode() == 2) {
            this.f1254d = null;
            this.f1255e = null;
        } else if (this.f1254d == null) {
            Context context = getContext();
            this.f1254d = new EdgeEffect(context);
            this.f1255e = new EdgeEffect(context);
        }
    }

    /* renamed from: g */
    private void m2244g(int i) {
        if (i == 0) {
            return;
        }
        if (this.f1263m) {
            mo1876b(0, i);
        } else {
            scrollBy(0, i);
        }
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f1249A == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f1249A = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f1249A;
    }

    /* renamed from: h */
    private void m2245h(int i) {
        int scrollY = getScrollY();
        boolean z = (scrollY > 0 || i > 0) && (scrollY < getScrollRange() || i < 0);
        float f = (float) i;
        if (!dispatchNestedPreFling(0.0f, f)) {
            dispatchNestedFling(0.0f, f, z);
            mo1895f(i);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public int mo1865a(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        if (rect.bottom < getChildAt(0).getHeight()) {
            i -= verticalFadingEdgeLength;
        }
        if (rect.bottom > i && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i) + 0, getChildAt(0).getBottom() - i);
        } else if (rect.top >= scrollY || rect.bottom >= i) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    /* renamed from: a */
    public void mo1866a(int i) {
        this.f1274z.mo1589c(i);
    }

    /* renamed from: a */
    public boolean mo1867a(int i, int i2) {
        return this.f1274z.mo1581a(i, i2);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0058  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x007b A[ADDED_TO_REGION] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1868a(int r17, int r18, int r19, int r20, int r21, int r22, int r23, int r24, boolean r25) {
        /*
            r16 = this;
            r0 = r16
            int r1 = r16.getOverScrollMode()
            int r2 = r16.computeHorizontalScrollRange()
            int r3 = r16.computeHorizontalScrollExtent()
            r4 = 0
            r5 = 1
            if (r2 <= r3) goto L_0x0014
            r2 = 1
            goto L_0x0015
        L_0x0014:
            r2 = 0
        L_0x0015:
            int r3 = r16.computeVerticalScrollRange()
            int r6 = r16.computeVerticalScrollExtent()
            if (r3 <= r6) goto L_0x0021
            r3 = 1
            goto L_0x0022
        L_0x0021:
            r3 = 0
        L_0x0022:
            if (r1 == 0) goto L_0x002b
            if (r1 != r5) goto L_0x0029
            if (r2 == 0) goto L_0x0029
            goto L_0x002b
        L_0x0029:
            r2 = 0
            goto L_0x002c
        L_0x002b:
            r2 = 1
        L_0x002c:
            if (r1 == 0) goto L_0x0035
            if (r1 != r5) goto L_0x0033
            if (r3 == 0) goto L_0x0033
            goto L_0x0035
        L_0x0033:
            r6 = 0
            goto L_0x0036
        L_0x0035:
            r6 = 1
        L_0x0036:
            int r1 = r19 + r17
            if (r2 != 0) goto L_0x003c
            r7 = 0
            goto L_0x003e
        L_0x003c:
            r7 = r23
        L_0x003e:
            int r2 = r20 + r18
            if (r6 != 0) goto L_0x0044
            r3 = 0
            goto L_0x0046
        L_0x0044:
            r3 = r24
        L_0x0046:
            int r6 = -r7
            int r7 = r7 + r21
            int r8 = -r3
            int r3 = r3 + r22
            if (r1 <= r7) goto L_0x0051
            r6 = r7
        L_0x004f:
            r1 = 1
            goto L_0x0056
        L_0x0051:
            if (r1 >= r6) goto L_0x0054
            goto L_0x004f
        L_0x0054:
            r6 = r1
            r1 = 0
        L_0x0056:
            if (r2 <= r3) goto L_0x005b
            r8 = r3
        L_0x0059:
            r2 = 1
            goto L_0x0060
        L_0x005b:
            if (r2 >= r8) goto L_0x005e
            goto L_0x0059
        L_0x005e:
            r8 = r2
            r2 = 0
        L_0x0060:
            if (r2 == 0) goto L_0x0076
            boolean r3 = r0.mo1877b((int) r5)
            if (r3 != 0) goto L_0x0076
            android.widget.OverScroller r9 = r0.f1253c
            r12 = 0
            r13 = 0
            r14 = 0
            int r15 = r16.getScrollRange()
            r10 = r6
            r11 = r8
            r9.springBack(r10, r11, r12, r13, r14, r15)
        L_0x0076:
            r0.onOverScrolled(r6, r8, r1, r2)
            if (r1 != 0) goto L_0x007d
            if (r2 == 0) goto L_0x007e
        L_0x007d:
            r4 = 1
        L_0x007e:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p009v4.widget.NestedScrollView.mo1868a(int, int, int, int, int, int, int, int, boolean):boolean");
    }

    /* renamed from: a */
    public boolean mo1869a(int i, int i2, int i3, int i4, int[] iArr, int i5) {
        return this.f1274z.mo1583a(i, i2, i3, i4, iArr, i5);
    }

    /* renamed from: a */
    public boolean mo1870a(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.f1274z.mo1585a(i, i2, iArr, iArr2, i3);
    }

    /* renamed from: a */
    public boolean mo1871a(KeyEvent keyEvent) {
        this.f1252b.setEmpty();
        int i = 130;
        if (m2237b()) {
            if (keyEvent.getAction() == 0) {
                int keyCode = keyEvent.getKeyCode();
                if (keyCode != 62) {
                    switch (keyCode) {
                        case 19:
                            return !keyEvent.isAltPressed() ? mo1894e(33) : mo1887d(33);
                        case 20:
                            return !keyEvent.isAltPressed() ? mo1894e(130) : mo1887d(130);
                        default:
                            return false;
                    }
                } else {
                    if (keyEvent.isShiftPressed()) {
                        i = 33;
                    }
                    mo1879c(i);
                }
            }
            return false;
        } else if (!isFocused() || keyEvent.getKeyCode() == 4) {
            return false;
        } else {
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
            return (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) ? false : true;
        }
    }

    public void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    public void addView(View view, int i) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i, layoutParams);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, layoutParams);
    }

    /* renamed from: b */
    public final void mo1876b(int i, int i2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f1251a > 250) {
                int max = Math.max(0, getChildAt(0).getHeight() - ((getHeight() - getPaddingBottom()) - getPaddingTop()));
                int scrollY = getScrollY();
                this.f1253c.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i2 + scrollY, max)) - scrollY);
                C0421r.m1791c(this);
            } else {
                if (!this.f1253c.isFinished()) {
                    this.f1253c.abortAnimation();
                }
                scrollBy(i, i2);
            }
            this.f1251a = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    /* renamed from: b */
    public boolean mo1877b(int i) {
        return this.f1274z.mo1580a(i);
    }

    /* renamed from: c */
    public final void mo1878c(int i, int i2) {
        mo1876b(i - getScrollX(), i2 - getScrollY());
    }

    /* renamed from: c */
    public boolean mo1879c(int i) {
        Rect rect;
        int i2 = 0;
        boolean z = i == 130;
        int height = getHeight();
        if (z) {
            this.f1252b.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                if (this.f1252b.top + height > childAt.getBottom()) {
                    rect = this.f1252b;
                    i2 = childAt.getBottom() - height;
                }
            }
            this.f1252b.bottom = this.f1252b.top + height;
            return m2230a(i, this.f1252b.top, this.f1252b.bottom);
        }
        this.f1252b.top = getScrollY() - height;
        if (this.f1252b.top < 0) {
            rect = this.f1252b;
        }
        this.f1252b.bottom = this.f1252b.top + height;
        return m2230a(i, this.f1252b.top, this.f1252b.bottom);
        rect.top = i2;
        this.f1252b.bottom = this.f1252b.top + height;
        return m2230a(i, this.f1252b.top, this.f1252b.bottom);
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (this.f1253c.computeScrollOffset()) {
            this.f1253c.getCurrX();
            int currY = this.f1253c.getCurrY();
            int i = currY - this.f1271u;
            if (mo1870a(0, i, this.f1269s, (int[]) null, 1)) {
                i -= this.f1269s[1];
            }
            int i2 = i;
            if (i2 != 0) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int i3 = scrollY;
                mo1868a(0, i2, getScrollX(), scrollY, 0, scrollRange, 0, 0, false);
                int scrollY2 = getScrollY() - i3;
                if (!mo1869a(0, scrollY2, 0, i2 - scrollY2, (int[]) null, 1)) {
                    int overScrollMode = getOverScrollMode();
                    if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                        m2243g();
                        if (currY <= 0 && i3 > 0) {
                            edgeEffect = this.f1254d;
                        } else if (currY >= scrollRange && i3 < scrollRange) {
                            edgeEffect = this.f1255e;
                        }
                        edgeEffect.onAbsorb((int) this.f1253c.getCurrVelocity());
                    }
                }
            }
            this.f1271u = currY;
            C0421r.m1791c(this);
            return;
        }
        if (mo1877b(1)) {
            mo1866a(1);
        }
        this.f1271u = 0;
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        int bottom = getChildAt(0).getBottom();
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    /* renamed from: d */
    public boolean mo1887d(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        this.f1252b.top = 0;
        this.f1252b.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            this.f1252b.bottom = getChildAt(childCount - 1).getBottom() + getPaddingBottom();
            this.f1252b.top = this.f1252b.bottom - height;
        }
        return m2230a(i, this.f1252b.top, this.f1252b.bottom);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo1871a(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f1274z.mo1579a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f1274z.mo1578a(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.f1274z.mo1584a(i, i2, iArr, iArr2);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f1274z.mo1582a(i, i2, i3, i4, iArr);
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f1254d != null) {
            int scrollY = getScrollY();
            if (!this.f1254d.isFinished()) {
                int save = canvas.save();
                int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
                canvas.translate((float) getPaddingLeft(), (float) Math.min(0, scrollY));
                this.f1254d.setSize(width, getHeight());
                if (this.f1254d.draw(canvas)) {
                    C0421r.m1791c(this);
                }
                canvas.restoreToCount(save);
            }
            if (!this.f1255e.isFinished()) {
                int save2 = canvas.save();
                int width2 = (getWidth() - getPaddingLeft()) - getPaddingRight();
                int height = getHeight();
                canvas.translate((float) ((-width2) + getPaddingLeft()), (float) (Math.max(getScrollRange(), scrollY) + height));
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f1255e.setSize(width2, height);
                if (this.f1255e.draw(canvas)) {
                    C0421r.m1791c(this);
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    /* renamed from: e */
    public boolean mo1894e(int i) {
        int bottom;
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !m2233a(findNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0 && (bottom = getChildAt(0).getBottom() - ((getScrollY() + getHeight()) - getPaddingBottom())) < maxScrollAmount) {
                maxScrollAmount = bottom;
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            m2244g(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.f1252b);
            offsetDescendantRectToMyCoords(findNextFocus, this.f1252b);
            m2244g(mo1865a(this.f1252b));
            findNextFocus.requestFocus(i);
        }
        if (findFocus == null || !findFocus.isFocused() || !m2232a(findFocus)) {
            return true;
        }
        int descendantFocusability = getDescendantFocusability();
        setDescendantFocusability(131072);
        requestFocus();
        setDescendantFocusability(descendantFocusability);
        return true;
    }

    /* renamed from: f */
    public void mo1895f(int i) {
        if (getChildCount() > 0) {
            mo1867a(2, 1);
            this.f1253c.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.f1271u = getScrollY();
            C0421r.m1791c(this);
        }
    }

    /* access modifiers changed from: protected */
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = (getChildAt(0).getBottom() - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        return this.f1273y.mo1595a();
    }

    /* access modifiers changed from: package-private */
    public int getScrollRange() {
        if (getChildCount() > 0) {
            return Math.max(0, getChildAt(0).getHeight() - ((getHeight() - getPaddingBottom()) - getPaddingTop()));
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public boolean hasNestedScrollingParent() {
        return this.f1274z.mo1586b();
    }

    public boolean isNestedScrollingEnabled() {
        return this.f1274z.mo1577a();
    }

    /* access modifiers changed from: protected */
    public void measureChild(View view, int i, int i2) {
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    /* access modifiers changed from: protected */
    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1258h = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.f1260j) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int verticalScrollFactorCompat = scrollY - ((int) (axisValue * getVerticalScrollFactorCompat()));
                if (verticalScrollFactorCompat < 0) {
                    verticalScrollFactorCompat = 0;
                } else if (verticalScrollFactorCompat > scrollRange) {
                    verticalScrollFactorCompat = scrollRange;
                }
                if (verticalScrollFactorCompat != scrollY) {
                    super.scrollTo(getScrollX(), verticalScrollFactorCompat);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 2 && this.f1260j) {
            return true;
        }
        int i = action & 255;
        if (i != 6) {
            switch (i) {
                case 0:
                    int y = (int) motionEvent.getY();
                    if (m2240d((int) motionEvent.getX(), y)) {
                        this.f1256f = y;
                        this.f1267q = motionEvent.getPointerId(0);
                        m2238c();
                        this.f1261k.addMovement(motionEvent);
                        this.f1253c.computeScrollOffset();
                        this.f1260j = !this.f1253c.isFinished();
                        mo1867a(2, 0);
                        break;
                    } else {
                        this.f1260j = false;
                        m2241e();
                        break;
                    }
                case 1:
                case 3:
                    this.f1260j = false;
                    this.f1267q = -1;
                    m2241e();
                    if (this.f1253c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                        C0421r.m1791c(this);
                    }
                    mo1866a(0);
                    break;
                case 2:
                    int i2 = this.f1267q;
                    if (i2 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i2);
                        if (findPointerIndex != -1) {
                            int y2 = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y2 - this.f1256f) > this.f1264n && (2 & getNestedScrollAxes()) == 0) {
                                this.f1260j = true;
                                this.f1256f = y2;
                                m2239d();
                                this.f1261k.addMovement(motionEvent);
                                this.f1270t = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                    break;
                                }
                            }
                        } else {
                            Log.e("NestedScrollView", "Invalid pointerId=" + i2 + " in onInterceptTouchEvent");
                            break;
                        }
                    }
                    break;
            }
        } else {
            m2229a(motionEvent);
        }
        return this.f1260j;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f1257g = false;
        if (this.f1259i != null && m2234a(this.f1259i, (View) this)) {
            m2236b(this.f1259i);
        }
        this.f1259i = null;
        if (!this.f1258h) {
            if (this.f1272v != null) {
                scrollTo(getScrollX(), this.f1272v.f1275a);
                this.f1272v = null;
            }
            int max = Math.max(0, (getChildCount() > 0 ? getChildAt(0).getMeasuredHeight() : 0) - (((i4 - i2) - getPaddingBottom()) - getPaddingTop()));
            if (getScrollY() > max) {
                scrollTo(getScrollX(), max);
            } else if (getScrollY() < 0) {
                scrollTo(getScrollX(), 0);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f1258h = true;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f1262l && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            int measuredHeight = getMeasuredHeight();
            if (childAt.getMeasuredHeight() < measuredHeight) {
                childAt.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), ((FrameLayout.LayoutParams) childAt.getLayoutParams()).width), View.MeasureSpec.makeMeasureSpec((measuredHeight - getPaddingTop()) - getPaddingBottom(), 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        m2245h((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        dispatchNestedPreScroll(i, i2, iArr, (int[]) null);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int scrollY = getScrollY();
        scrollBy(0, i4);
        int scrollY2 = getScrollY() - scrollY;
        dispatchNestedScroll(0, scrollY2, 0, i4 - scrollY2, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f1273y.mo1598a(view, view2, i);
        startNestedScroll(2);
    }

    /* access modifiers changed from: protected */
    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View findNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, (View) null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (findNextFocus != null && !m2232a(findNextFocus)) {
            return findNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0491c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0491c cVar = (C0491c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.f1272v = cVar;
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        C0491c cVar = new C0491c(super.onSaveInstanceState());
        cVar.f1275a = getScrollY();
        return cVar;
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        if (this.f1250B != null) {
            this.f1250B.mo1928a(this, i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && m2233a(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f1252b);
            offsetDescendantRectToMyCoords(findFocus, this.f1252b);
            m2244g(mo1865a(this.f1252b));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return (i & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.f1273y.mo1596a(view);
        stopNestedScroll();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0066, code lost:
        if (r10.f1253c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0068;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0068, code lost:
        android.support.p009v4.p020h.C0421r.m1791c(r23);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x020c, code lost:
        if (r10.f1253c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0068;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r24) {
        /*
            r23 = this;
            r10 = r23
            r11 = r24
            r23.m2239d()
            android.view.MotionEvent r12 = android.view.MotionEvent.obtain(r24)
            int r0 = r24.getActionMasked()
            r13 = 0
            if (r0 != 0) goto L_0x0014
            r10.f1270t = r13
        L_0x0014:
            int r1 = r10.f1270t
            float r1 = (float) r1
            r14 = 0
            r12.offsetLocation(r14, r1)
            r1 = -1
            r15 = 1
            switch(r0) {
                case 0: goto L_0x0210;
                case 1: goto L_0x01d8;
                case 2: goto L_0x0072;
                case 3: goto L_0x0047;
                case 4: goto L_0x0020;
                case 5: goto L_0x0034;
                case 6: goto L_0x0022;
                default: goto L_0x0020;
            }
        L_0x0020:
            goto L_0x0249
        L_0x0022:
            r23.m2229a((android.view.MotionEvent) r24)
            int r0 = r10.f1267q
            int r0 = r11.findPointerIndex(r0)
            float r0 = r11.getY(r0)
            int r0 = (int) r0
            r10.f1256f = r0
            goto L_0x0249
        L_0x0034:
            int r0 = r24.getActionIndex()
            float r1 = r11.getY(r0)
            int r1 = (int) r1
            r10.f1256f = r1
            int r0 = r11.getPointerId(r0)
            r10.f1267q = r0
            goto L_0x0249
        L_0x0047:
            boolean r0 = r10.f1260j
            if (r0 == 0) goto L_0x006b
            int r0 = r23.getChildCount()
            if (r0 <= 0) goto L_0x006b
            android.widget.OverScroller r2 = r10.f1253c
            int r3 = r23.getScrollX()
            int r4 = r23.getScrollY()
            r5 = 0
            r6 = 0
            r7 = 0
            int r8 = r23.getScrollRange()
            boolean r0 = r2.springBack(r3, r4, r5, r6, r7, r8)
            if (r0 == 0) goto L_0x006b
        L_0x0068:
            android.support.p009v4.p020h.C0421r.m1791c(r23)
        L_0x006b:
            r10.f1267q = r1
            r23.m2242f()
            goto L_0x0249
        L_0x0072:
            int r0 = r10.f1267q
            int r9 = r11.findPointerIndex(r0)
            if (r9 != r1) goto L_0x0099
            java.lang.String r0 = "NestedScrollView"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Invalid pointerId="
            r1.append(r2)
            int r2 = r10.f1267q
            r1.append(r2)
            java.lang.String r2 = " in onTouchEvent"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.e(r0, r1)
            goto L_0x0249
        L_0x0099:
            float r0 = r11.getY(r9)
            int r6 = (int) r0
            int r0 = r10.f1256f
            int r7 = r0 - r6
            r1 = 0
            int[] r3 = r10.f1269s
            int[] r4 = r10.f1268r
            r5 = 0
            r0 = r10
            r2 = r7
            boolean r0 = r0.mo1870a(r1, r2, r3, r4, r5)
            if (r0 == 0) goto L_0x00c6
            int[] r0 = r10.f1269s
            r0 = r0[r15]
            int r7 = r7 - r0
            int[] r0 = r10.f1268r
            r0 = r0[r15]
            float r0 = (float) r0
            r12.offsetLocation(r14, r0)
            int r0 = r10.f1270t
            int[] r1 = r10.f1268r
            r1 = r1[r15]
            int r0 = r0 + r1
            r10.f1270t = r0
        L_0x00c6:
            boolean r0 = r10.f1260j
            if (r0 != 0) goto L_0x00e6
            int r0 = java.lang.Math.abs(r7)
            int r1 = r10.f1264n
            if (r0 <= r1) goto L_0x00e6
            android.view.ViewParent r0 = r23.getParent()
            if (r0 == 0) goto L_0x00db
            r0.requestDisallowInterceptTouchEvent(r15)
        L_0x00db:
            r10.f1260j = r15
            if (r7 <= 0) goto L_0x00e3
            int r0 = r10.f1264n
            int r7 = r7 - r0
            goto L_0x00e6
        L_0x00e3:
            int r0 = r10.f1264n
            int r7 = r7 + r0
        L_0x00e6:
            r8 = r7
            boolean r0 = r10.f1260j
            if (r0 == 0) goto L_0x0249
            int[] r0 = r10.f1268r
            r0 = r0[r15]
            int r6 = r6 - r0
            r10.f1256f = r6
            int r16 = r23.getScrollY()
            int r7 = r23.getScrollRange()
            int r0 = r23.getOverScrollMode()
            if (r0 == 0) goto L_0x0108
            if (r0 != r15) goto L_0x0105
            if (r7 <= 0) goto L_0x0105
            goto L_0x0108
        L_0x0105:
            r17 = 0
            goto L_0x010a
        L_0x0108:
            r17 = 1
        L_0x010a:
            r1 = 0
            r3 = 0
            int r4 = r23.getScrollY()
            r5 = 0
            r18 = 0
            r19 = 0
            r20 = 1
            r0 = r10
            r2 = r8
            r6 = r7
            r21 = r7
            r7 = r18
            r14 = r8
            r8 = r19
            r22 = r9
            r9 = r20
            boolean r0 = r0.mo1868a(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            if (r0 == 0) goto L_0x0136
            boolean r0 = r10.mo1877b((int) r13)
            if (r0 != 0) goto L_0x0136
            android.view.VelocityTracker r0 = r10.f1261k
            r0.clear()
        L_0x0136:
            int r0 = r23.getScrollY()
            int r2 = r0 - r16
            int r4 = r14 - r2
            r1 = 0
            r3 = 0
            int[] r5 = r10.f1268r
            r6 = 0
            r0 = r10
            boolean r0 = r0.mo1869a(r1, r2, r3, r4, r5, r6)
            if (r0 == 0) goto L_0x0167
            int r0 = r10.f1256f
            int[] r1 = r10.f1268r
            r1 = r1[r15]
            int r0 = r0 - r1
            r10.f1256f = r0
            int[] r0 = r10.f1268r
            r0 = r0[r15]
            float r0 = (float) r0
            r1 = 0
            r12.offsetLocation(r1, r0)
            int r0 = r10.f1270t
            int[] r1 = r10.f1268r
            r1 = r1[r15]
            int r0 = r0 + r1
            r10.f1270t = r0
            goto L_0x0249
        L_0x0167:
            if (r17 == 0) goto L_0x0249
            r23.m2243g()
            int r0 = r16 + r14
            if (r0 >= 0) goto L_0x0196
            android.widget.EdgeEffect r0 = r10.f1254d
            float r1 = (float) r14
            int r2 = r23.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            r2 = r22
            float r2 = r11.getX(r2)
            int r3 = r23.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            android.support.p009v4.widget.C0506f.m2325a(r0, r1, r2)
            android.widget.EdgeEffect r0 = r10.f1255e
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01c0
            android.widget.EdgeEffect r0 = r10.f1255e
        L_0x0192:
            r0.onRelease()
            goto L_0x01c0
        L_0x0196:
            r1 = r21
            r2 = r22
            if (r0 <= r1) goto L_0x01c0
            android.widget.EdgeEffect r0 = r10.f1255e
            float r1 = (float) r14
            int r3 = r23.getHeight()
            float r3 = (float) r3
            float r1 = r1 / r3
            r3 = 1065353216(0x3f800000, float:1.0)
            float r2 = r11.getX(r2)
            int r4 = r23.getWidth()
            float r4 = (float) r4
            float r2 = r2 / r4
            float r3 = r3 - r2
            android.support.p009v4.widget.C0506f.m2325a(r0, r1, r3)
            android.widget.EdgeEffect r0 = r10.f1254d
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01c0
            android.widget.EdgeEffect r0 = r10.f1254d
            goto L_0x0192
        L_0x01c0:
            android.widget.EdgeEffect r0 = r10.f1254d
            if (r0 == 0) goto L_0x0249
            android.widget.EdgeEffect r0 = r10.f1254d
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x01d4
            android.widget.EdgeEffect r0 = r10.f1255e
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0249
        L_0x01d4:
            android.support.p009v4.p020h.C0421r.m1791c(r23)
            goto L_0x0249
        L_0x01d8:
            android.view.VelocityTracker r0 = r10.f1261k
            r2 = 1000(0x3e8, float:1.401E-42)
            int r3 = r10.f1266p
            float r3 = (float) r3
            r0.computeCurrentVelocity(r2, r3)
            int r2 = r10.f1267q
            float r0 = r0.getYVelocity(r2)
            int r0 = (int) r0
            int r2 = java.lang.Math.abs(r0)
            int r3 = r10.f1265o
            if (r2 <= r3) goto L_0x01f7
            int r0 = -r0
            r10.m2245h(r0)
            goto L_0x006b
        L_0x01f7:
            android.widget.OverScroller r2 = r10.f1253c
            int r3 = r23.getScrollX()
            int r4 = r23.getScrollY()
            r5 = 0
            r6 = 0
            r7 = 0
            int r8 = r23.getScrollRange()
            boolean r0 = r2.springBack(r3, r4, r5, r6, r7, r8)
            if (r0 == 0) goto L_0x006b
            goto L_0x0068
        L_0x0210:
            int r0 = r23.getChildCount()
            if (r0 != 0) goto L_0x0217
            return r13
        L_0x0217:
            android.widget.OverScroller r0 = r10.f1253c
            boolean r0 = r0.isFinished()
            r0 = r0 ^ r15
            r10.f1260j = r0
            if (r0 == 0) goto L_0x022b
            android.view.ViewParent r0 = r23.getParent()
            if (r0 == 0) goto L_0x022b
            r0.requestDisallowInterceptTouchEvent(r15)
        L_0x022b:
            android.widget.OverScroller r0 = r10.f1253c
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0238
            android.widget.OverScroller r0 = r10.f1253c
            r0.abortAnimation()
        L_0x0238:
            float r0 = r24.getY()
            int r0 = (int) r0
            r10.f1256f = r0
            int r0 = r11.getPointerId(r13)
            r10.f1267q = r0
            r0 = 2
            r10.mo1867a((int) r0, (int) r13)
        L_0x0249:
            android.view.VelocityTracker r0 = r10.f1261k
            if (r0 == 0) goto L_0x0252
            android.view.VelocityTracker r0 = r10.f1261k
            r0.addMovement(r12)
        L_0x0252:
            r12.recycle()
            return r15
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p009v4.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f1257g) {
            m2236b(view2);
        } else {
            this.f1259i = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        return m2231a(rect, z);
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            m2241e();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        this.f1257g = true;
        super.requestLayout();
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            int b = m2235b(i, (getWidth() - getPaddingRight()) - getPaddingLeft(), childAt.getWidth());
            int b2 = m2235b(i2, (getHeight() - getPaddingBottom()) - getPaddingTop(), childAt.getHeight());
            if (b != getScrollX() || b2 != getScrollY()) {
                super.scrollTo(b, b2);
            }
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.f1262l) {
            this.f1262l = z;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.f1274z.mo1576a(z);
    }

    public void setOnScrollChangeListener(C0490b bVar) {
        this.f1250B = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.f1263m = z;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i) {
        return this.f1274z.mo1587b(i);
    }

    public void stopNestedScroll() {
        this.f1274z.mo1588c();
    }
}
