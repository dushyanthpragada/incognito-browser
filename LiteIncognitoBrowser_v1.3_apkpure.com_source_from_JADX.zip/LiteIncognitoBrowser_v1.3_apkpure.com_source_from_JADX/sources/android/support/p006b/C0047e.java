package android.support.p006b;

import android.content.ComponentName;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.util.List;

/* renamed from: android.support.b.e */
public final class C0047e {

    /* renamed from: a */
    private final Object f74a = new Object();

    /* renamed from: b */
    private final C0051g f75b;

    /* renamed from: c */
    private final C0048f f76c;

    /* renamed from: d */
    private final ComponentName f77d;

    C0047e(C0051g gVar, C0048f fVar, ComponentName componentName) {
        this.f75b = gVar;
        this.f76c = fVar;
        this.f77d = componentName;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public IBinder mo71a() {
        return this.f76c.asBinder();
    }

    /* renamed from: a */
    public boolean mo72a(Uri uri, Bundle bundle, List<Bundle> list) {
        try {
            return this.f75b.mo83a(this.f76c, uri, bundle, list);
        } catch (RemoteException unused) {
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public ComponentName mo73b() {
        return this.f77d;
    }
}
