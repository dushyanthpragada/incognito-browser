package android.support.p009v4.widget;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.support.p009v4.widget.C0504e;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.FilterQueryProvider;
import android.widget.Filterable;

/* renamed from: android.support.v4.widget.d */
public abstract class C0501d extends BaseAdapter implements C0504e.C0505a, Filterable {

    /* renamed from: a */
    protected boolean f1310a;

    /* renamed from: b */
    protected boolean f1311b;

    /* renamed from: c */
    protected Cursor f1312c;

    /* renamed from: d */
    protected Context f1313d;

    /* renamed from: e */
    protected int f1314e;

    /* renamed from: f */
    protected C0502a f1315f;

    /* renamed from: g */
    protected DataSetObserver f1316g;

    /* renamed from: h */
    protected C0504e f1317h;

    /* renamed from: i */
    protected FilterQueryProvider f1318i;

    /* renamed from: android.support.v4.widget.d$a */
    private class C0502a extends ContentObserver {
        C0502a() {
            super(new Handler());
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean z) {
            C0501d.this.mo1976b();
        }
    }

    /* renamed from: android.support.v4.widget.d$b */
    private class C0503b extends DataSetObserver {
        C0503b() {
        }

        public void onChanged() {
            C0501d.this.f1310a = true;
            C0501d.this.notifyDataSetChanged();
        }

        public void onInvalidated() {
            C0501d.this.f1310a = false;
            C0501d.this.notifyDataSetInvalidated();
        }
    }

    public C0501d(Context context, Cursor cursor, boolean z) {
        mo1971a(context, cursor, z ? 1 : 2);
    }

    /* renamed from: a */
    public Cursor mo1968a() {
        return this.f1312c;
    }

    /* renamed from: a */
    public Cursor mo1969a(CharSequence charSequence) {
        return this.f1318i != null ? this.f1318i.runQuery(charSequence) : this.f1312c;
    }

    /* renamed from: a */
    public abstract View mo1970a(Context context, Cursor cursor, ViewGroup viewGroup);

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1971a(Context context, Cursor cursor, int i) {
        C0503b bVar;
        boolean z = false;
        if ((i & 1) == 1) {
            i |= 2;
            this.f1311b = true;
        } else {
            this.f1311b = false;
        }
        if (cursor != null) {
            z = true;
        }
        this.f1312c = cursor;
        this.f1310a = z;
        this.f1313d = context;
        this.f1314e = z ? cursor.getColumnIndexOrThrow("_id") : -1;
        if ((i & 2) == 2) {
            this.f1315f = new C0502a();
            bVar = new C0503b();
        } else {
            bVar = null;
            this.f1315f = null;
        }
        this.f1316g = bVar;
        if (z) {
            if (this.f1315f != null) {
                cursor.registerContentObserver(this.f1315f);
            }
            if (this.f1316g != null) {
                cursor.registerDataSetObserver(this.f1316g);
            }
        }
    }

    /* renamed from: a */
    public void mo1972a(Cursor cursor) {
        Cursor b = mo1974b(cursor);
        if (b != null) {
            b.close();
        }
    }

    /* renamed from: a */
    public abstract void mo1973a(View view, Context context, Cursor cursor);

    /* renamed from: b */
    public Cursor mo1974b(Cursor cursor) {
        if (cursor == this.f1312c) {
            return null;
        }
        Cursor cursor2 = this.f1312c;
        if (cursor2 != null) {
            if (this.f1315f != null) {
                cursor2.unregisterContentObserver(this.f1315f);
            }
            if (this.f1316g != null) {
                cursor2.unregisterDataSetObserver(this.f1316g);
            }
        }
        this.f1312c = cursor;
        if (cursor != null) {
            if (this.f1315f != null) {
                cursor.registerContentObserver(this.f1315f);
            }
            if (this.f1316g != null) {
                cursor.registerDataSetObserver(this.f1316g);
            }
            this.f1314e = cursor.getColumnIndexOrThrow("_id");
            this.f1310a = true;
            notifyDataSetChanged();
            return cursor2;
        }
        this.f1314e = -1;
        this.f1310a = false;
        notifyDataSetInvalidated();
        return cursor2;
    }

    /* renamed from: b */
    public View mo1975b(Context context, Cursor cursor, ViewGroup viewGroup) {
        return mo1970a(context, cursor, viewGroup);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public void mo1976b() {
        if (this.f1311b && this.f1312c != null && !this.f1312c.isClosed()) {
            this.f1310a = this.f1312c.requery();
        }
    }

    /* renamed from: c */
    public CharSequence mo1977c(Cursor cursor) {
        return cursor == null ? "" : cursor.toString();
    }

    public int getCount() {
        if (!this.f1310a || this.f1312c == null) {
            return 0;
        }
        return this.f1312c.getCount();
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (!this.f1310a) {
            return null;
        }
        this.f1312c.moveToPosition(i);
        if (view == null) {
            view = mo1975b(this.f1313d, this.f1312c, viewGroup);
        }
        mo1973a(view, this.f1313d, this.f1312c);
        return view;
    }

    public Filter getFilter() {
        if (this.f1317h == null) {
            this.f1317h = new C0504e(this);
        }
        return this.f1317h;
    }

    public Object getItem(int i) {
        if (!this.f1310a || this.f1312c == null) {
            return null;
        }
        this.f1312c.moveToPosition(i);
        return this.f1312c;
    }

    public long getItemId(int i) {
        if (!this.f1310a || this.f1312c == null || !this.f1312c.moveToPosition(i)) {
            return 0;
        }
        return this.f1312c.getLong(this.f1314e);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (!this.f1310a) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        } else if (!this.f1312c.moveToPosition(i)) {
            throw new IllegalStateException("couldn't move cursor to position " + i);
        } else {
            if (view == null) {
                view = mo1970a(this.f1313d, this.f1312c, viewGroup);
            }
            mo1973a(view, this.f1313d, this.f1312c);
            return view;
        }
    }

    public boolean hasStableIds() {
        return true;
    }
}
