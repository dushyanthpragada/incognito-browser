package android.support.p009v4.p013c.p014a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

/* renamed from: android.support.v4.c.a.c */
class C0305c extends Drawable implements Drawable.Callback, C0304b, C0312f {

    /* renamed from: a */
    static final PorterDuff.Mode f950a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b */
    C0306a f951b;

    /* renamed from: c */
    Drawable f952c;

    /* renamed from: d */
    private int f953d;

    /* renamed from: e */
    private PorterDuff.Mode f954e;

    /* renamed from: f */
    private boolean f955f;

    /* renamed from: g */
    private boolean f956g;

    /* renamed from: android.support.v4.c.a.c$a */
    protected static abstract class C0306a extends Drawable.ConstantState {

        /* renamed from: a */
        int f957a;

        /* renamed from: b */
        Drawable.ConstantState f958b;

        /* renamed from: c */
        ColorStateList f959c = null;

        /* renamed from: d */
        PorterDuff.Mode f960d = C0305c.f950a;

        C0306a(C0306a aVar, Resources resources) {
            if (aVar != null) {
                this.f957a = aVar.f957a;
                this.f958b = aVar.f958b;
                this.f959c = aVar.f959c;
                this.f960d = aVar.f960d;
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo1230a() {
            return this.f958b != null;
        }

        public int getChangingConfigurations() {
            return this.f957a | (this.f958b != null ? this.f958b.getChangingConfigurations() : 0);
        }

        public Drawable newDrawable() {
            return newDrawable((Resources) null);
        }

        public abstract Drawable newDrawable(Resources resources);
    }

    /* renamed from: android.support.v4.c.a.c$b */
    private static class C0307b extends C0306a {
        C0307b(C0306a aVar, Resources resources) {
            super(aVar, resources);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0305c(this, resources);
        }
    }

    C0305c(Drawable drawable) {
        this.f951b = mo1201b();
        mo1199a(drawable);
    }

    C0305c(C0306a aVar, Resources resources) {
        this.f951b = aVar;
        m1379a(resources);
    }

    /* renamed from: a */
    private void m1379a(Resources resources) {
        if (this.f951b != null && this.f951b.f958b != null) {
            mo1199a(mo1200a(this.f951b.f958b, resources));
        }
    }

    /* renamed from: a */
    private boolean m1380a(int[] iArr) {
        if (!mo1202c()) {
            return false;
        }
        ColorStateList colorStateList = this.f951b.f959c;
        PorterDuff.Mode mode = this.f951b.f960d;
        if (colorStateList == null || mode == null) {
            this.f955f = false;
            clearColorFilter();
        } else {
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (!(this.f955f && colorForState == this.f953d && mode == this.f954e)) {
                setColorFilter(colorForState, mode);
                this.f953d = colorForState;
                this.f954e = mode;
                this.f955f = true;
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public final Drawable mo1198a() {
        return this.f952c;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public Drawable mo1200a(Drawable.ConstantState constantState, Resources resources) {
        return constantState.newDrawable(resources);
    }

    /* renamed from: a */
    public final void mo1199a(Drawable drawable) {
        if (this.f952c != null) {
            this.f952c.setCallback((Drawable.Callback) null);
        }
        this.f952c = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            setVisible(drawable.isVisible(), true);
            setState(drawable.getState());
            setLevel(drawable.getLevel());
            setBounds(drawable.getBounds());
            if (this.f951b != null) {
                this.f951b.f958b = drawable.getConstantState();
            }
        }
        invalidateSelf();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public C0306a mo1201b() {
        return new C0307b(this.f951b, (Resources) null);
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public boolean mo1202c() {
        return true;
    }

    public void draw(Canvas canvas) {
        this.f952c.draw(canvas);
    }

    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | (this.f951b != null ? this.f951b.getChangingConfigurations() : 0) | this.f952c.getChangingConfigurations();
    }

    public Drawable.ConstantState getConstantState() {
        if (this.f951b == null || !this.f951b.mo1230a()) {
            return null;
        }
        this.f951b.f957a = getChangingConfigurations();
        return this.f951b;
    }

    public Drawable getCurrent() {
        return this.f952c.getCurrent();
    }

    public int getIntrinsicHeight() {
        return this.f952c.getIntrinsicHeight();
    }

    public int getIntrinsicWidth() {
        return this.f952c.getIntrinsicWidth();
    }

    public int getMinimumHeight() {
        return this.f952c.getMinimumHeight();
    }

    public int getMinimumWidth() {
        return this.f952c.getMinimumWidth();
    }

    public int getOpacity() {
        return this.f952c.getOpacity();
    }

    public boolean getPadding(Rect rect) {
        return this.f952c.getPadding(rect);
    }

    public int[] getState() {
        return this.f952c.getState();
    }

    public Region getTransparentRegion() {
        return this.f952c.getTransparentRegion();
    }

    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public boolean isStateful() {
        ColorStateList colorStateList = (!mo1202c() || this.f951b == null) ? null : this.f951b.f959c;
        return (colorStateList != null && colorStateList.isStateful()) || this.f952c.isStateful();
    }

    public void jumpToCurrentState() {
        this.f952c.jumpToCurrentState();
    }

    public Drawable mutate() {
        if (!this.f956g && super.mutate() == this) {
            this.f951b = mo1201b();
            if (this.f952c != null) {
                this.f952c.mutate();
            }
            if (this.f951b != null) {
                this.f951b.f958b = this.f952c != null ? this.f952c.getConstantState() : null;
            }
            this.f956g = true;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        if (this.f952c != null) {
            this.f952c.setBounds(rect);
        }
    }

    /* access modifiers changed from: protected */
    public boolean onLevelChange(int i) {
        return this.f952c.setLevel(i);
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        scheduleSelf(runnable, j);
    }

    public void setAlpha(int i) {
        this.f952c.setAlpha(i);
    }

    public void setChangingConfigurations(int i) {
        this.f952c.setChangingConfigurations(i);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f952c.setColorFilter(colorFilter);
    }

    public void setDither(boolean z) {
        this.f952c.setDither(z);
    }

    public void setFilterBitmap(boolean z) {
        this.f952c.setFilterBitmap(z);
    }

    public boolean setState(int[] iArr) {
        return m1380a(iArr) || this.f952c.setState(iArr);
    }

    public void setTint(int i) {
        setTintList(ColorStateList.valueOf(i));
    }

    public void setTintList(ColorStateList colorStateList) {
        this.f951b.f959c = colorStateList;
        m1380a(getState());
    }

    public void setTintMode(PorterDuff.Mode mode) {
        this.f951b.f960d = mode;
        m1380a(getState());
    }

    public boolean setVisible(boolean z, boolean z2) {
        return super.setVisible(z, z2) || this.f952c.setVisible(z, z2);
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
