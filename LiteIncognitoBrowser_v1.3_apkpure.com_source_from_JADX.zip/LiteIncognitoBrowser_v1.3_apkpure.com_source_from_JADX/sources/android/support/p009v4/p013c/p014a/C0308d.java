package android.support.p009v4.p013c.p014a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.p009v4.p013c.p014a.C0305c;

/* renamed from: android.support.v4.c.a.d */
class C0308d extends C0305c {

    /* renamed from: android.support.v4.c.a.d$a */
    private static class C0309a extends C0305c.C0306a {
        C0309a(C0305c.C0306a aVar, Resources resources) {
            super(aVar, resources);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0308d(this, resources);
        }
    }

    C0308d(Drawable drawable) {
        super(drawable);
    }

    C0308d(C0305c.C0306a aVar, Resources resources) {
        super(aVar, resources);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public C0305c.C0306a mo1201b() {
        return new C0309a(this.f951b, (Resources) null);
    }

    public boolean isAutoMirrored() {
        return this.f952c.isAutoMirrored();
    }

    public void setAutoMirrored(boolean z) {
        this.f952c.setAutoMirrored(z);
    }
}
