package android.support.p009v4.p013c;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.support.p009v4.p011b.p012a.C0283b;
import android.support.p009v4.p013c.C0316c;
import android.support.p009v4.p018f.C0342b;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/* renamed from: android.support.v4.c.g */
class C0321g implements C0316c.C0317a {

    /* renamed from: android.support.v4.c.g$a */
    private interface C0324a<T> {
        /* renamed from: a */
        boolean mo1247a(T t);

        /* renamed from: b */
        int mo1248b(T t);
    }

    C0321g() {
    }

    /* renamed from: a */
    private C0283b.C0286c m1432a(C0283b.C0285b bVar, int i) {
        return (C0283b.C0286c) m1433a(bVar.mo1166a(), i, new C0324a<C0283b.C0286c>() {
            /* renamed from: a */
            public int mo1248b(C0283b.C0286c cVar) {
                return cVar.mo1168b();
            }

            /* renamed from: b */
            public boolean mo1247a(C0283b.C0286c cVar) {
                return cVar.mo1169c();
            }
        });
    }

    /* renamed from: a */
    private static <T> T m1433a(T[] tArr, int i, C0324a<T> aVar) {
        int i2 = (i & 1) == 0 ? 400 : 700;
        boolean z = (i & 2) != 0;
        T t = null;
        int i3 = Integer.MAX_VALUE;
        for (T t2 : tArr) {
            int abs = (Math.abs(aVar.mo1248b(t2) - i2) * 2) + (aVar.mo1247a(t2) == z ? 0 : 1);
            if (t == null || i3 > abs) {
                t = t2;
                i3 = abs;
            }
        }
        return t;
    }

    /* renamed from: a */
    public Typeface mo1241a(Context context, Resources resources, int i, String str, int i2) {
        File a = C0325h.m1449a(context);
        if (a == null) {
            return null;
        }
        try {
            if (!C0325h.m1454a(a, resources, i)) {
                return null;
            }
            Typeface createFromFile = Typeface.createFromFile(a.getPath());
            a.delete();
            return createFromFile;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            a.delete();
        }
    }

    /* renamed from: a */
    public Typeface mo1242a(Context context, CancellationSignal cancellationSignal, C0342b.C0348b[] bVarArr, int i) {
        InputStream inputStream;
        InputStream inputStream2 = null;
        if (bVarArr.length < 1) {
            return null;
        }
        try {
            inputStream = context.getContentResolver().openInputStream(mo1245a(bVarArr, i).mo1306a());
            try {
                Typeface a = mo1244a(context, inputStream);
                C0325h.m1453a((Closeable) inputStream);
                return a;
            } catch (IOException unused) {
                C0325h.m1453a((Closeable) inputStream);
                return null;
            } catch (Throwable th) {
                th = th;
                inputStream2 = inputStream;
                C0325h.m1453a((Closeable) inputStream2);
                throw th;
            }
        } catch (IOException unused2) {
            inputStream = null;
            C0325h.m1453a((Closeable) inputStream);
            return null;
        } catch (Throwable th2) {
            th = th2;
            C0325h.m1453a((Closeable) inputStream2);
            throw th;
        }
    }

    /* renamed from: a */
    public Typeface mo1243a(Context context, C0283b.C0285b bVar, Resources resources, int i) {
        C0283b.C0286c a = m1432a(bVar, i);
        if (a == null) {
            return null;
        }
        return C0316c.m1406a(context, resources, a.mo1170d(), a.mo1167a(), i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public Typeface mo1244a(Context context, InputStream inputStream) {
        File a = C0325h.m1449a(context);
        if (a == null) {
            return null;
        }
        try {
            if (!C0325h.m1455a(a, inputStream)) {
                return null;
            }
            Typeface createFromFile = Typeface.createFromFile(a.getPath());
            a.delete();
            return createFromFile;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            a.delete();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0342b.C0348b mo1245a(C0342b.C0348b[] bVarArr, int i) {
        return (C0342b.C0348b) m1433a(bVarArr, i, new C0324a<C0342b.C0348b>() {
            /* renamed from: a */
            public int mo1248b(C0342b.C0348b bVar) {
                return bVar.mo1308c();
            }

            /* renamed from: b */
            public boolean mo1247a(C0342b.C0348b bVar) {
                return bVar.mo1309d();
            }
        });
    }
}
