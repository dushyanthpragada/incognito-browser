package android.support.p009v4.p017e;

import android.os.Build;
import android.os.Trace;

/* renamed from: android.support.v4.e.f */
public final class C0340f {
    /* renamed from: a */
    public static void m1471a() {
        if (Build.VERSION.SDK_INT >= 18) {
            Trace.endSection();
        }
    }

    /* renamed from: a */
    public static void m1472a(String str) {
        if (Build.VERSION.SDK_INT >= 18) {
            Trace.beginSection(str);
        }
    }
}
