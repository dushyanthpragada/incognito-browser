package android.support.p009v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.widget.CompoundButton;
import java.lang.reflect.Field;

/* renamed from: android.support.v4.widget.c */
public final class C0497c {

    /* renamed from: a */
    private static final C0500c f1307a = (Build.VERSION.SDK_INT >= 23 ? new C0499b() : Build.VERSION.SDK_INT >= 21 ? new C0498a() : new C0500c());

    /* renamed from: android.support.v4.widget.c$a */
    static class C0498a extends C0500c {
        C0498a() {
        }

        /* renamed from: a */
        public void mo1965a(CompoundButton compoundButton, ColorStateList colorStateList) {
            compoundButton.setButtonTintList(colorStateList);
        }

        /* renamed from: a */
        public void mo1966a(CompoundButton compoundButton, PorterDuff.Mode mode) {
            compoundButton.setButtonTintMode(mode);
        }
    }

    /* renamed from: android.support.v4.widget.c$b */
    static class C0499b extends C0498a {
        C0499b() {
        }

        /* renamed from: a */
        public Drawable mo1967a(CompoundButton compoundButton) {
            return compoundButton.getButtonDrawable();
        }
    }

    /* renamed from: android.support.v4.widget.c$c */
    static class C0500c {

        /* renamed from: a */
        private static Field f1308a;

        /* renamed from: b */
        private static boolean f1309b;

        C0500c() {
        }

        /* renamed from: a */
        public Drawable mo1967a(CompoundButton compoundButton) {
            if (!f1309b) {
                try {
                    f1308a = CompoundButton.class.getDeclaredField("mButtonDrawable");
                    f1308a.setAccessible(true);
                } catch (NoSuchFieldException e) {
                    Log.i("CompoundButtonCompat", "Failed to retrieve mButtonDrawable field", e);
                }
                f1309b = true;
            }
            if (f1308a != null) {
                try {
                    return (Drawable) f1308a.get(compoundButton);
                } catch (IllegalAccessException e2) {
                    Log.i("CompoundButtonCompat", "Failed to get button drawable via reflection", e2);
                    f1308a = null;
                }
            }
            return null;
        }

        /* renamed from: a */
        public void mo1965a(CompoundButton compoundButton, ColorStateList colorStateList) {
            if (compoundButton instanceof C0529n) {
                ((C0529n) compoundButton).setSupportButtonTintList(colorStateList);
            }
        }

        /* renamed from: a */
        public void mo1966a(CompoundButton compoundButton, PorterDuff.Mode mode) {
            if (compoundButton instanceof C0529n) {
                ((C0529n) compoundButton).setSupportButtonTintMode(mode);
            }
        }
    }

    /* renamed from: a */
    public static Drawable m2302a(CompoundButton compoundButton) {
        return f1307a.mo1967a(compoundButton);
    }

    /* renamed from: a */
    public static void m2303a(CompoundButton compoundButton, ColorStateList colorStateList) {
        f1307a.mo1965a(compoundButton, colorStateList);
    }

    /* renamed from: a */
    public static void m2304a(CompoundButton compoundButton, PorterDuff.Mode mode) {
        f1307a.mo1966a(compoundButton, mode);
    }
}
