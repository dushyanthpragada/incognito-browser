package android.support.p009v4.p017e;

import android.os.Parcel;
import android.os.Parcelable;

@Deprecated
/* renamed from: android.support.v4.e.c */
public final class C0333c {

    /* renamed from: android.support.v4.e.c$a */
    static class C0334a<T> implements Parcelable.ClassLoaderCreator<T> {

        /* renamed from: a */
        private final C0335d<T> f982a;

        C0334a(C0335d<T> dVar) {
            this.f982a = dVar;
        }

        public T createFromParcel(Parcel parcel) {
            return this.f982a.mo329b(parcel, (ClassLoader) null);
        }

        public T createFromParcel(Parcel parcel, ClassLoader classLoader) {
            return this.f982a.mo329b(parcel, classLoader);
        }

        public T[] newArray(int i) {
            return this.f982a.mo330b(i);
        }
    }

    @Deprecated
    /* renamed from: a */
    public static <T> Parcelable.Creator<T> m1464a(C0335d<T> dVar) {
        return new C0334a(dVar);
    }
}
