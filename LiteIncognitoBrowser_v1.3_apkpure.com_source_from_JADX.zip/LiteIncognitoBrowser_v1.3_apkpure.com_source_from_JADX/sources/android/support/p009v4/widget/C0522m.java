package android.support.p009v4.widget;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.p009v4.p017e.C0329a;
import android.widget.TextView;

/* renamed from: android.support.v4.widget.m */
public final class C0522m {

    /* renamed from: a */
    static final C0528f f1334a = (C0329a.m1460a() ? new C0527e() : Build.VERSION.SDK_INT >= 23 ? new C0526d() : Build.VERSION.SDK_INT >= 18 ? new C0525c() : Build.VERSION.SDK_INT >= 17 ? new C0524b() : Build.VERSION.SDK_INT >= 16 ? new C0523a() : new C0528f());

    /* renamed from: android.support.v4.widget.m$a */
    static class C0523a extends C0528f {
        C0523a() {
        }
    }

    /* renamed from: android.support.v4.widget.m$b */
    static class C0524b extends C0523a {
        C0524b() {
        }

        /* renamed from: a */
        public void mo2016a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            boolean z = true;
            if (textView.getLayoutDirection() != 1) {
                z = false;
            }
            Drawable drawable5 = z ? drawable3 : drawable;
            if (!z) {
                drawable = drawable3;
            }
            textView.setCompoundDrawables(drawable5, drawable2, drawable, drawable4);
        }
    }

    /* renamed from: android.support.v4.widget.m$c */
    static class C0525c extends C0524b {
        C0525c() {
        }

        /* renamed from: a */
        public void mo2016a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            textView.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        }
    }

    /* renamed from: android.support.v4.widget.m$d */
    static class C0526d extends C0525c {
        C0526d() {
        }

        /* renamed from: a */
        public void mo2017a(TextView textView, int i) {
            textView.setTextAppearance(i);
        }
    }

    /* renamed from: android.support.v4.widget.m$e */
    static class C0527e extends C0526d {
        C0527e() {
        }
    }

    /* renamed from: android.support.v4.widget.m$f */
    static class C0528f {
        C0528f() {
        }

        /* renamed from: a */
        public void mo2017a(TextView textView, int i) {
            textView.setTextAppearance(textView.getContext(), i);
        }

        /* renamed from: a */
        public void mo2016a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            textView.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        }
    }

    /* renamed from: a */
    public static void m2378a(TextView textView, int i) {
        f1334a.mo2017a(textView, i);
    }

    /* renamed from: a */
    public static void m2379a(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        f1334a.mo2016a(textView, drawable, drawable2, drawable3, drawable4);
    }
}
