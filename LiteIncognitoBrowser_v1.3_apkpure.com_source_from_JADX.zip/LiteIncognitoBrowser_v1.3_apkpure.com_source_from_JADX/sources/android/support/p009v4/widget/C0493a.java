package android.support.p009v4.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.support.p009v4.p020h.C0421r;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* renamed from: android.support.v4.widget.a */
public abstract class C0493a implements View.OnTouchListener {

    /* renamed from: r */
    private static final int f1276r = ViewConfiguration.getTapTimeout();

    /* renamed from: a */
    final C0494a f1277a = new C0494a();

    /* renamed from: b */
    final View f1278b;

    /* renamed from: c */
    boolean f1279c;

    /* renamed from: d */
    boolean f1280d;

    /* renamed from: e */
    boolean f1281e;

    /* renamed from: f */
    private final Interpolator f1282f = new AccelerateInterpolator();

    /* renamed from: g */
    private Runnable f1283g;

    /* renamed from: h */
    private float[] f1284h = {0.0f, 0.0f};

    /* renamed from: i */
    private float[] f1285i = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: j */
    private int f1286j;

    /* renamed from: k */
    private int f1287k;

    /* renamed from: l */
    private float[] f1288l = {0.0f, 0.0f};

    /* renamed from: m */
    private float[] f1289m = {0.0f, 0.0f};

    /* renamed from: n */
    private float[] f1290n = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: o */
    private boolean f1291o;

    /* renamed from: p */
    private boolean f1292p;

    /* renamed from: q */
    private boolean f1293q;

    /* renamed from: android.support.v4.widget.a$a */
    private static class C0494a {

        /* renamed from: a */
        private int f1294a;

        /* renamed from: b */
        private int f1295b;

        /* renamed from: c */
        private float f1296c;

        /* renamed from: d */
        private float f1297d;

        /* renamed from: e */
        private long f1298e = Long.MIN_VALUE;

        /* renamed from: f */
        private long f1299f = 0;

        /* renamed from: g */
        private int f1300g = 0;

        /* renamed from: h */
        private int f1301h = 0;

        /* renamed from: i */
        private long f1302i = -1;

        /* renamed from: j */
        private float f1303j;

        /* renamed from: k */
        private int f1304k;

        C0494a() {
        }

        /* renamed from: a */
        private float m2289a(float f) {
            return (-4.0f * f * f) + (f * 4.0f);
        }

        /* renamed from: a */
        private float m2290a(long j) {
            if (j < this.f1298e) {
                return 0.0f;
            }
            if (this.f1302i < 0 || j < this.f1302i) {
                return C0493a.m2267a(((float) (j - this.f1298e)) / ((float) this.f1294a), 0.0f, 1.0f) * 0.5f;
            }
            return (1.0f - this.f1303j) + (this.f1303j * C0493a.m2267a(((float) (j - this.f1302i)) / ((float) this.f1304k), 0.0f, 1.0f));
        }

        /* renamed from: a */
        public void mo1953a() {
            this.f1298e = AnimationUtils.currentAnimationTimeMillis();
            this.f1302i = -1;
            this.f1299f = this.f1298e;
            this.f1303j = 0.5f;
            this.f1300g = 0;
            this.f1301h = 0;
        }

        /* renamed from: a */
        public void mo1954a(float f, float f2) {
            this.f1296c = f;
            this.f1297d = f2;
        }

        /* renamed from: a */
        public void mo1955a(int i) {
            this.f1294a = i;
        }

        /* renamed from: b */
        public void mo1956b() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f1304k = C0493a.m2270a((int) (currentAnimationTimeMillis - this.f1298e), 0, this.f1295b);
            this.f1303j = m2290a(currentAnimationTimeMillis);
            this.f1302i = currentAnimationTimeMillis;
        }

        /* renamed from: b */
        public void mo1957b(int i) {
            this.f1295b = i;
        }

        /* renamed from: c */
        public boolean mo1958c() {
            return this.f1302i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f1302i + ((long) this.f1304k);
        }

        /* renamed from: d */
        public void mo1959d() {
            if (this.f1299f == 0) {
                throw new RuntimeException("Cannot compute scroll delta before calling start()");
            }
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            float a = m2289a(m2290a(currentAnimationTimeMillis));
            this.f1299f = currentAnimationTimeMillis;
            float f = ((float) (currentAnimationTimeMillis - this.f1299f)) * a;
            this.f1300g = (int) (this.f1296c * f);
            this.f1301h = (int) (f * this.f1297d);
        }

        /* renamed from: e */
        public int mo1960e() {
            return (int) (this.f1296c / Math.abs(this.f1296c));
        }

        /* renamed from: f */
        public int mo1961f() {
            return (int) (this.f1297d / Math.abs(this.f1297d));
        }

        /* renamed from: g */
        public int mo1962g() {
            return this.f1300g;
        }

        /* renamed from: h */
        public int mo1963h() {
            return this.f1301h;
        }
    }

    /* renamed from: android.support.v4.widget.a$b */
    private class C0495b implements Runnable {
        C0495b() {
        }

        public void run() {
            if (C0493a.this.f1281e) {
                if (C0493a.this.f1279c) {
                    C0493a.this.f1279c = false;
                    C0493a.this.f1277a.mo1953a();
                }
                C0494a aVar = C0493a.this.f1277a;
                if (aVar.mo1958c() || !C0493a.this.mo1941a()) {
                    C0493a.this.f1281e = false;
                    return;
                }
                if (C0493a.this.f1280d) {
                    C0493a.this.f1280d = false;
                    C0493a.this.mo1944b();
                }
                aVar.mo1959d();
                C0493a.this.mo1940a(aVar.mo1962g(), aVar.mo1963h());
                C0421r.m1782a(C0493a.this.f1278b, (Runnable) this);
            }
        }
    }

    public C0493a(View view) {
        this.f1278b = view;
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        float f = (float) ((int) ((displayMetrics.density * 1575.0f) + 0.5f));
        mo1937a(f, f);
        float f2 = (float) ((int) ((displayMetrics.density * 315.0f) + 0.5f));
        mo1942b(f2, f2);
        mo1938a(1);
        mo1949e(Float.MAX_VALUE, Float.MAX_VALUE);
        mo1947d(0.2f, 0.2f);
        mo1945c(1.0f, 1.0f);
        mo1943b(f1276r);
        mo1946c(500);
        mo1948d(500);
    }

    /* renamed from: a */
    static float m2267a(float f, float f2, float f3) {
        return f > f3 ? f3 : f < f2 ? f2 : f;
    }

    /* renamed from: a */
    private float m2268a(float f, float f2, float f3, float f4) {
        float f5;
        float a = m2267a(f * f2, 0.0f, f3);
        float f6 = m2273f(f2 - f4, a) - m2273f(f4, a);
        if (f6 < 0.0f) {
            f5 = -this.f1282f.getInterpolation(-f6);
        } else if (f6 <= 0.0f) {
            return 0.0f;
        } else {
            f5 = this.f1282f.getInterpolation(f6);
        }
        return m2267a(f5, -1.0f, 1.0f);
    }

    /* renamed from: a */
    private float m2269a(int i, float f, float f2, float f3) {
        float a = m2268a(this.f1284h[i], f2, this.f1285i[i], f);
        if (a == 0.0f) {
            return 0.0f;
        }
        float f4 = this.f1288l[i];
        float f5 = this.f1289m[i];
        float f6 = this.f1290n[i];
        float f7 = f4 * f3;
        return a > 0.0f ? m2267a(a * f7, f5, f6) : -m2267a((-a) * f7, f5, f6);
    }

    /* renamed from: a */
    static int m2270a(int i, int i2, int i3) {
        return i > i3 ? i3 : i < i2 ? i2 : i;
    }

    /* renamed from: c */
    private void m2271c() {
        if (this.f1283g == null) {
            this.f1283g = new C0495b();
        }
        this.f1281e = true;
        this.f1279c = true;
        if (this.f1291o || this.f1287k <= 0) {
            this.f1283g.run();
        } else {
            C0421r.m1783a(this.f1278b, this.f1283g, (long) this.f1287k);
        }
        this.f1291o = true;
    }

    /* renamed from: d */
    private void m2272d() {
        if (this.f1279c) {
            this.f1281e = false;
        } else {
            this.f1277a.mo1956b();
        }
    }

    /* renamed from: f */
    private float m2273f(float f, float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        switch (this.f1286j) {
            case 0:
            case 1:
                if (f < f2) {
                    return f >= 0.0f ? 1.0f - (f / f2) : (!this.f1281e || this.f1286j != 1) ? 0.0f : 1.0f;
                }
                break;
            case 2:
                if (f < 0.0f) {
                    return f / (-f2);
                }
                break;
            default:
                return 0.0f;
        }
    }

    /* renamed from: a */
    public C0493a mo1937a(float f, float f2) {
        this.f1290n[0] = f / 1000.0f;
        this.f1290n[1] = f2 / 1000.0f;
        return this;
    }

    /* renamed from: a */
    public C0493a mo1938a(int i) {
        this.f1286j = i;
        return this;
    }

    /* renamed from: a */
    public C0493a mo1939a(boolean z) {
        if (this.f1292p && !z) {
            m2272d();
        }
        this.f1292p = z;
        return this;
    }

    /* renamed from: a */
    public abstract void mo1940a(int i, int i2);

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo1941a() {
        C0494a aVar = this.f1277a;
        int f = aVar.mo1961f();
        int e = aVar.mo1960e();
        if (f == 0 || !mo1951f(f)) {
            return e != 0 && mo1950e(e);
        }
        return true;
    }

    /* renamed from: b */
    public C0493a mo1942b(float f, float f2) {
        this.f1289m[0] = f / 1000.0f;
        this.f1289m[1] = f2 / 1000.0f;
        return this;
    }

    /* renamed from: b */
    public C0493a mo1943b(int i) {
        this.f1287k = i;
        return this;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1944b() {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
        this.f1278b.onTouchEvent(obtain);
        obtain.recycle();
    }

    /* renamed from: c */
    public C0493a mo1945c(float f, float f2) {
        this.f1288l[0] = f / 1000.0f;
        this.f1288l[1] = f2 / 1000.0f;
        return this;
    }

    /* renamed from: c */
    public C0493a mo1946c(int i) {
        this.f1277a.mo1955a(i);
        return this;
    }

    /* renamed from: d */
    public C0493a mo1947d(float f, float f2) {
        this.f1284h[0] = f;
        this.f1284h[1] = f2;
        return this;
    }

    /* renamed from: d */
    public C0493a mo1948d(int i) {
        this.f1277a.mo1957b(i);
        return this;
    }

    /* renamed from: e */
    public C0493a mo1949e(float f, float f2) {
        this.f1285i[0] = f;
        this.f1285i[1] = f2;
        return this;
    }

    /* renamed from: e */
    public abstract boolean mo1950e(int i);

    /* renamed from: f */
    public abstract boolean mo1951f(int i);

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.f1292p) {
            return false;
        }
        switch (motionEvent.getActionMasked()) {
            case 0:
                this.f1280d = true;
                this.f1291o = false;
                break;
            case 1:
            case 3:
                m2272d();
                break;
            case 2:
                break;
        }
        this.f1277a.mo1954a(m2269a(0, motionEvent.getX(), (float) view.getWidth(), (float) this.f1278b.getWidth()), m2269a(1, motionEvent.getY(), (float) view.getHeight(), (float) this.f1278b.getHeight()));
        if (!this.f1281e && mo1941a()) {
            m2271c();
        }
        return this.f1293q && this.f1281e;
    }
}
