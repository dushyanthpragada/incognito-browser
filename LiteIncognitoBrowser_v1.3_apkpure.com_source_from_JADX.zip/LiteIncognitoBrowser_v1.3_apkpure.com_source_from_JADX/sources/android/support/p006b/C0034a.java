package android.support.p006b;

import android.net.Uri;
import android.os.Bundle;

/* renamed from: android.support.b.a */
public class C0034a {
    /* renamed from: a */
    public void mo50a(int i, Uri uri, boolean z, Bundle bundle) {
    }

    /* renamed from: a */
    public void mo51a(int i, Bundle bundle) {
    }

    /* renamed from: a */
    public void mo52a(Bundle bundle) {
    }

    /* renamed from: a */
    public void mo53a(String str, Bundle bundle) {
    }

    /* renamed from: b */
    public void mo54b(String str, Bundle bundle) {
    }
}
