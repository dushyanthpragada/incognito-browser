package android.support.p009v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.ImageView;

/* renamed from: android.support.v4.widget.g */
public class C0509g {

    /* renamed from: a */
    static final C0511b f1324a = (Build.VERSION.SDK_INT >= 21 ? new C0512c() : new C0510a());

    /* renamed from: android.support.v4.widget.g$a */
    static class C0510a implements C0511b {
        C0510a() {
        }

        /* renamed from: a */
        public ColorStateList mo1999a(ImageView imageView) {
            if (imageView instanceof C0530o) {
                return ((C0530o) imageView).getSupportImageTintList();
            }
            return null;
        }

        /* renamed from: a */
        public void mo2000a(ImageView imageView, ColorStateList colorStateList) {
            if (imageView instanceof C0530o) {
                ((C0530o) imageView).setSupportImageTintList(colorStateList);
            }
        }

        /* renamed from: a */
        public void mo2001a(ImageView imageView, PorterDuff.Mode mode) {
            if (imageView instanceof C0530o) {
                ((C0530o) imageView).setSupportImageTintMode(mode);
            }
        }

        /* renamed from: b */
        public PorterDuff.Mode mo2002b(ImageView imageView) {
            if (imageView instanceof C0530o) {
                return ((C0530o) imageView).getSupportImageTintMode();
            }
            return null;
        }
    }

    /* renamed from: android.support.v4.widget.g$b */
    interface C0511b {
        /* renamed from: a */
        ColorStateList mo1999a(ImageView imageView);

        /* renamed from: a */
        void mo2000a(ImageView imageView, ColorStateList colorStateList);

        /* renamed from: a */
        void mo2001a(ImageView imageView, PorterDuff.Mode mode);

        /* renamed from: b */
        PorterDuff.Mode mo2002b(ImageView imageView);
    }

    /* renamed from: android.support.v4.widget.g$c */
    static class C0512c extends C0510a {
        C0512c() {
        }

        /* renamed from: a */
        public ColorStateList mo1999a(ImageView imageView) {
            return imageView.getImageTintList();
        }

        /* renamed from: a */
        public void mo2000a(ImageView imageView, ColorStateList colorStateList) {
            imageView.setImageTintList(colorStateList);
            if (Build.VERSION.SDK_INT == 21) {
                Drawable drawable = imageView.getDrawable();
                boolean z = (imageView.getImageTintList() == null || imageView.getImageTintMode() == null) ? false : true;
                if (drawable != null && z) {
                    if (drawable.isStateful()) {
                        drawable.setState(imageView.getDrawableState());
                    }
                    imageView.setImageDrawable(drawable);
                }
            }
        }

        /* renamed from: a */
        public void mo2001a(ImageView imageView, PorterDuff.Mode mode) {
            imageView.setImageTintMode(mode);
            if (Build.VERSION.SDK_INT == 21) {
                Drawable drawable = imageView.getDrawable();
                boolean z = (imageView.getImageTintList() == null || imageView.getImageTintMode() == null) ? false : true;
                if (drawable != null && z) {
                    if (drawable.isStateful()) {
                        drawable.setState(imageView.getDrawableState());
                    }
                    imageView.setImageDrawable(drawable);
                }
            }
        }

        /* renamed from: b */
        public PorterDuff.Mode mo2002b(ImageView imageView) {
            return imageView.getImageTintMode();
        }
    }

    /* renamed from: a */
    public static ColorStateList m2334a(ImageView imageView) {
        return f1324a.mo1999a(imageView);
    }

    /* renamed from: a */
    public static void m2335a(ImageView imageView, ColorStateList colorStateList) {
        f1324a.mo2000a(imageView, colorStateList);
    }

    /* renamed from: a */
    public static void m2336a(ImageView imageView, PorterDuff.Mode mode) {
        f1324a.mo2001a(imageView, mode);
    }

    /* renamed from: b */
    public static PorterDuff.Mode m2337b(ImageView imageView) {
        return f1324a.mo2002b(imageView);
    }
}
