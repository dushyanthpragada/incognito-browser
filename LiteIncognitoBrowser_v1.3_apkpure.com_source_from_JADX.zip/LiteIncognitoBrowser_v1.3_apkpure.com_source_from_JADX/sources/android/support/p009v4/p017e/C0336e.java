package android.support.p009v4.p017e;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p009v4.p017e.C0330b;

/* renamed from: android.support.v4.e.e */
public class C0336e implements Parcelable {
    public static final Parcelable.Creator<C0336e> CREATOR = new Parcelable.Creator<C0336e>() {
        /* renamed from: a */
        public C0336e createFromParcel(Parcel parcel) {
            return new C0336e(parcel);
        }

        /* renamed from: a */
        public C0336e[] newArray(int i) {
            return new C0336e[i];
        }
    };

    /* renamed from: a */
    final boolean f983a = false;

    /* renamed from: b */
    final Handler f984b = null;

    /* renamed from: c */
    C0330b f985c;

    /* renamed from: android.support.v4.e.e$a */
    class C0338a extends C0330b.C0331a {
        C0338a() {
        }

        /* renamed from: a */
        public void mo1275a(int i, Bundle bundle) {
            if (C0336e.this.f984b != null) {
                C0336e.this.f984b.post(new C0339b(i, bundle));
            } else {
                C0336e.this.mo1282a(i, bundle);
            }
        }
    }

    /* renamed from: android.support.v4.e.e$b */
    class C0339b implements Runnable {

        /* renamed from: a */
        final int f987a;

        /* renamed from: b */
        final Bundle f988b;

        C0339b(int i, Bundle bundle) {
            this.f987a = i;
            this.f988b = bundle;
        }

        public void run() {
            C0336e.this.mo1282a(this.f987a, this.f988b);
        }
    }

    C0336e(Parcel parcel) {
        this.f985c = C0330b.C0331a.m1462a(parcel.readStrongBinder());
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo1282a(int i, Bundle bundle) {
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.f985c == null) {
                this.f985c = new C0338a();
            }
            parcel.writeStrongBinder(this.f985c.asBinder());
        }
    }
}
