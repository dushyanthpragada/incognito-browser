package android.support.p009v4.p013c;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.support.p009v4.p011b.p012a.C0283b;
import android.support.p009v4.p011b.p012a.C0288c;
import android.support.p009v4.p018f.C0342b;
import android.support.p009v4.p019g.C0364g;

/* renamed from: android.support.v4.c.c */
public class C0316c {

    /* renamed from: a */
    private static final C0317a f966a = (Build.VERSION.SDK_INT >= 26 ? new C0320f() : (Build.VERSION.SDK_INT < 24 || !C0319e.m1417a()) ? Build.VERSION.SDK_INT >= 21 ? new C0318d() : new C0321g() : new C0319e());

    /* renamed from: b */
    private static final C0364g<String, Typeface> f967b = new C0364g<>(16);

    /* renamed from: android.support.v4.c.c$a */
    interface C0317a {
        /* renamed from: a */
        Typeface mo1241a(Context context, Resources resources, int i, String str, int i2);

        /* renamed from: a */
        Typeface mo1242a(Context context, CancellationSignal cancellationSignal, C0342b.C0348b[] bVarArr, int i);

        /* renamed from: a */
        Typeface mo1243a(Context context, C0283b.C0285b bVar, Resources resources, int i);
    }

    /* renamed from: a */
    public static Typeface m1406a(Context context, Resources resources, int i, String str, int i2) {
        Typeface a = f966a.mo1241a(context, resources, i, str, i2);
        if (a != null) {
            f967b.mo1367a(m1410b(resources, i, i2), a);
        }
        return a;
    }

    /* renamed from: a */
    public static Typeface m1407a(Context context, CancellationSignal cancellationSignal, C0342b.C0348b[] bVarArr, int i) {
        return f966a.mo1242a(context, cancellationSignal, bVarArr, i);
    }

    /* renamed from: a */
    public static Typeface m1408a(Context context, C0283b.C0284a aVar, Resources resources, int i, int i2, C0288c.C0289a aVar2, Handler handler, boolean z) {
        Typeface typeface;
        if (aVar instanceof C0283b.C0287d) {
            C0283b.C0287d dVar = (C0283b.C0287d) aVar;
            boolean z2 = false;
            if (!z ? aVar2 == null : dVar.mo1172b() == 0) {
                z2 = true;
            }
            typeface = C0342b.m1480a(context, dVar.mo1171a(), aVar2, handler, z2, z ? dVar.mo1173c() : -1, i2);
        } else {
            typeface = f966a.mo1243a(context, (C0283b.C0285b) aVar, resources, i2);
            if (aVar2 != null) {
                if (typeface != null) {
                    aVar2.mo1177a(typeface, handler);
                } else {
                    aVar2.mo1175a(-3, handler);
                }
            }
        }
        if (typeface != null) {
            f967b.mo1367a(m1410b(resources, i, i2), typeface);
        }
        return typeface;
    }

    /* renamed from: a */
    public static Typeface m1409a(Resources resources, int i, int i2) {
        return f967b.mo1366a(m1410b(resources, i, i2));
    }

    /* renamed from: b */
    private static String m1410b(Resources resources, int i, int i2) {
        return resources.getResourcePackageName(i) + "-" + i + "-" + i2;
    }
}
