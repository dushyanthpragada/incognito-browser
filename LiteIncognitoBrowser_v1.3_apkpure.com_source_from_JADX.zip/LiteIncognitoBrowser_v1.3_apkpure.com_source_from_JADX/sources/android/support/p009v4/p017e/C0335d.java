package android.support.p009v4.p017e;

import android.os.Parcel;

@Deprecated
/* renamed from: android.support.v4.e.d */
public interface C0335d<T> {
    /* renamed from: b */
    T mo329b(Parcel parcel, ClassLoader classLoader);

    /* renamed from: b */
    T[] mo330b(int i);
}
