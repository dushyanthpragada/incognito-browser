package android.support.p009v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build;
import android.widget.EdgeEffect;

/* renamed from: android.support.v4.widget.f */
public final class C0506f {

    /* renamed from: b */
    private static final C0508b f1322b = (Build.VERSION.SDK_INT >= 21 ? new C0507a() : new C0508b());

    /* renamed from: a */
    private EdgeEffect f1323a;

    /* renamed from: android.support.v4.widget.f$a */
    static class C0507a extends C0508b {
        C0507a() {
        }

        /* renamed from: a */
        public void mo1998a(EdgeEffect edgeEffect, float f, float f2) {
            edgeEffect.onPull(f, f2);
        }
    }

    /* renamed from: android.support.v4.widget.f$b */
    static class C0508b {
        C0508b() {
        }

        /* renamed from: a */
        public void mo1998a(EdgeEffect edgeEffect, float f, float f2) {
            edgeEffect.onPull(f);
        }
    }

    @Deprecated
    public C0506f(Context context) {
        this.f1323a = new EdgeEffect(context);
    }

    /* renamed from: a */
    public static void m2325a(EdgeEffect edgeEffect, float f, float f2) {
        f1322b.mo1998a(edgeEffect, f, f2);
    }

    @Deprecated
    /* renamed from: a */
    public void mo1992a(int i, int i2) {
        this.f1323a.setSize(i, i2);
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo1993a() {
        return this.f1323a.isFinished();
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo1994a(float f, float f2) {
        f1322b.mo1998a(this.f1323a, f, f2);
        return true;
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo1995a(int i) {
        this.f1323a.onAbsorb(i);
        return true;
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo1996a(Canvas canvas) {
        return this.f1323a.draw(canvas);
    }

    @Deprecated
    /* renamed from: b */
    public boolean mo1997b() {
        this.f1323a.onRelease();
        return this.f1323a.isFinished();
    }
}
