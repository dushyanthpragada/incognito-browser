package android.support.p009v4.widget;

import android.database.Cursor;
import android.widget.Filter;

/* renamed from: android.support.v4.widget.e */
class C0504e extends Filter {

    /* renamed from: a */
    C0505a f1321a;

    /* renamed from: android.support.v4.widget.e$a */
    interface C0505a {
        /* renamed from: a */
        Cursor mo1968a();

        /* renamed from: a */
        Cursor mo1969a(CharSequence charSequence);

        /* renamed from: a */
        void mo1972a(Cursor cursor);

        /* renamed from: c */
        CharSequence mo1977c(Cursor cursor);
    }

    C0504e(C0505a aVar) {
        this.f1321a = aVar;
    }

    public CharSequence convertResultToString(Object obj) {
        return this.f1321a.mo1977c((Cursor) obj);
    }

    /* access modifiers changed from: protected */
    public Filter.FilterResults performFiltering(CharSequence charSequence) {
        Cursor a = this.f1321a.mo1969a(charSequence);
        Filter.FilterResults filterResults = new Filter.FilterResults();
        if (a != null) {
            filterResults.count = a.getCount();
        } else {
            filterResults.count = 0;
            a = null;
        }
        filterResults.values = a;
        return filterResults;
    }

    /* access modifiers changed from: protected */
    public void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
        Cursor a = this.f1321a.mo1968a();
        if (filterResults.values != null && filterResults.values != a) {
            this.f1321a.mo1972a((Cursor) filterResults.values);
        }
    }
}
