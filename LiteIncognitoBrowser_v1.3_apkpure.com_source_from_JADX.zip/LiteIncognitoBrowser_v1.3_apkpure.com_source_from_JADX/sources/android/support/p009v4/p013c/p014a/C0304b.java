package android.support.p009v4.p013c.p014a;

import android.graphics.drawable.Drawable;

/* renamed from: android.support.v4.c.a.b */
public interface C0304b {
    /* renamed from: a */
    Drawable mo1198a();

    /* renamed from: a */
    void mo1199a(Drawable drawable);
}
