package android.support.p009v4.p013c.p014a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.support.p009v4.p013c.p014a.C0305c;
import android.util.Log;
import java.lang.reflect.Method;

/* renamed from: android.support.v4.c.a.e */
class C0310e extends C0308d {

    /* renamed from: d */
    private static Method f961d;

    /* renamed from: android.support.v4.c.a.e$a */
    private static class C0311a extends C0305c.C0306a {
        C0311a(C0305c.C0306a aVar, Resources resources) {
            super(aVar, resources);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0310e(this, resources);
        }
    }

    C0310e(Drawable drawable) {
        super(drawable);
        m1388d();
    }

    C0310e(C0305c.C0306a aVar, Resources resources) {
        super(aVar, resources);
        m1388d();
    }

    /* renamed from: d */
    private void m1388d() {
        if (f961d == null) {
            try {
                f961d = Drawable.class.getDeclaredMethod("isProjected", new Class[0]);
            } catch (Exception e) {
                Log.w("DrawableWrapperApi21", "Failed to retrieve Drawable#isProjected() method", e);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public C0305c.C0306a mo1201b() {
        return new C0311a(this.f951b, (Resources) null);
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public boolean mo1202c() {
        if (Build.VERSION.SDK_INT != 21) {
            return false;
        }
        Drawable drawable = this.f952c;
        return (drawable instanceof GradientDrawable) || (drawable instanceof DrawableContainer) || (drawable instanceof InsetDrawable) || (drawable instanceof RippleDrawable);
    }

    public Rect getDirtyBounds() {
        return this.f952c.getDirtyBounds();
    }

    public void getOutline(Outline outline) {
        this.f952c.getOutline(outline);
    }

    public void setHotspot(float f, float f2) {
        this.f952c.setHotspot(f, f2);
    }

    public void setHotspotBounds(int i, int i2, int i3, int i4) {
        this.f952c.setHotspotBounds(i, i2, i3, i4);
    }

    public boolean setState(int[] iArr) {
        if (!super.setState(iArr)) {
            return false;
        }
        invalidateSelf();
        return true;
    }

    public void setTint(int i) {
        if (mo1202c()) {
            super.setTint(i);
        } else {
            this.f952c.setTint(i);
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        if (mo1202c()) {
            super.setTintList(colorStateList);
        } else {
            this.f952c.setTintList(colorStateList);
        }
    }

    public void setTintMode(PorterDuff.Mode mode) {
        if (mo1202c()) {
            super.setTintMode(mode);
        } else {
            this.f952c.setTintMode(mode);
        }
    }
}
