package android.support.p006b;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.p006b.C0051g;

/* renamed from: android.support.b.d */
public abstract class C0045d implements ServiceConnection {
    /* renamed from: a */
    public abstract void mo69a(ComponentName componentName, C0035b bVar);

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        mo69a(componentName, new C0035b(C0051g.C0052a.m94a(iBinder), componentName) {
        });
    }
}
