package android.support.p009v4.p017e;

import android.os.Build;

/* renamed from: android.support.v4.e.a */
public class C0329a {
    @Deprecated
    /* renamed from: a */
    public static boolean m1460a() {
        return Build.VERSION.SDK_INT >= 27;
    }
}
