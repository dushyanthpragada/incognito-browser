package android.support.p009v4.widget;

import android.content.Context;
import android.view.animation.Interpolator;
import android.widget.OverScroller;

@Deprecated
/* renamed from: android.support.v4.widget.l */
public final class C0521l {

    /* renamed from: a */
    OverScroller f1333a;

    C0521l(Context context, Interpolator interpolator) {
        this.f1333a = interpolator != null ? new OverScroller(context, interpolator) : new OverScroller(context);
    }

    @Deprecated
    /* renamed from: a */
    public static C0521l m2366a(Context context) {
        return m2367a(context, (Interpolator) null);
    }

    @Deprecated
    /* renamed from: a */
    public static C0521l m2367a(Context context, Interpolator interpolator) {
        return new C0521l(context, interpolator);
    }

    @Deprecated
    /* renamed from: a */
    public void mo2006a(int i, int i2, int i3, int i4, int i5) {
        this.f1333a.startScroll(i, i2, i3, i4, i5);
    }

    @Deprecated
    /* renamed from: a */
    public void mo2007a(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        this.f1333a.fling(i, i2, i3, i4, i5, i6, i7, i8);
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo2008a() {
        return this.f1333a.isFinished();
    }

    @Deprecated
    /* renamed from: b */
    public int mo2009b() {
        return this.f1333a.getCurrX();
    }

    @Deprecated
    /* renamed from: c */
    public int mo2010c() {
        return this.f1333a.getCurrY();
    }

    @Deprecated
    /* renamed from: d */
    public int mo2011d() {
        return this.f1333a.getFinalX();
    }

    @Deprecated
    /* renamed from: e */
    public int mo2012e() {
        return this.f1333a.getFinalY();
    }

    @Deprecated
    /* renamed from: f */
    public float mo2013f() {
        return this.f1333a.getCurrVelocity();
    }

    @Deprecated
    /* renamed from: g */
    public boolean mo2014g() {
        return this.f1333a.computeScrollOffset();
    }

    @Deprecated
    /* renamed from: h */
    public void mo2015h() {
        this.f1333a.abortAnimation();
    }
}
