package android.support.p009v4.widget;

import android.os.Build;
import android.support.p009v4.p020h.C0402d;
import android.support.p009v4.p020h.C0421r;
import android.util.Log;
import android.view.View;
import android.widget.PopupWindow;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* renamed from: android.support.v4.widget.j */
public final class C0515j {

    /* renamed from: a */
    static final C0519d f1326a = (Build.VERSION.SDK_INT >= 23 ? new C0518c() : Build.VERSION.SDK_INT >= 21 ? new C0517b() : Build.VERSION.SDK_INT >= 19 ? new C0516a() : new C0519d());

    /* renamed from: android.support.v4.widget.j$a */
    static class C0516a extends C0519d {
        C0516a() {
        }

        /* renamed from: a */
        public void mo2003a(PopupWindow popupWindow, View view, int i, int i2, int i3) {
            popupWindow.showAsDropDown(view, i, i2, i3);
        }
    }

    /* renamed from: android.support.v4.widget.j$b */
    static class C0517b extends C0516a {

        /* renamed from: a */
        private static Field f1327a;

        static {
            try {
                f1327a = PopupWindow.class.getDeclaredField("mOverlapAnchor");
                f1327a.setAccessible(true);
            } catch (NoSuchFieldException e) {
                Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", e);
            }
        }

        C0517b() {
        }

        /* renamed from: a */
        public void mo2004a(PopupWindow popupWindow, boolean z) {
            if (f1327a != null) {
                try {
                    f1327a.set(popupWindow, Boolean.valueOf(z));
                } catch (IllegalAccessException e) {
                    Log.i("PopupWindowCompatApi21", "Could not set overlap anchor field in PopupWindow", e);
                }
            }
        }
    }

    /* renamed from: android.support.v4.widget.j$c */
    static class C0518c extends C0517b {
        C0518c() {
        }

        /* renamed from: a */
        public void mo2005a(PopupWindow popupWindow, int i) {
            popupWindow.setWindowLayoutType(i);
        }

        /* renamed from: a */
        public void mo2004a(PopupWindow popupWindow, boolean z) {
            popupWindow.setOverlapAnchor(z);
        }
    }

    /* renamed from: android.support.v4.widget.j$d */
    static class C0519d {

        /* renamed from: a */
        private static Method f1328a;

        /* renamed from: b */
        private static boolean f1329b;

        C0519d() {
        }

        /* renamed from: a */
        public void mo2005a(PopupWindow popupWindow, int i) {
            if (!f1329b) {
                Class<PopupWindow> cls = PopupWindow.class;
                try {
                    f1328a = cls.getDeclaredMethod("setWindowLayoutType", new Class[]{Integer.TYPE});
                    f1328a.setAccessible(true);
                } catch (Exception unused) {
                }
                f1329b = true;
            }
            if (f1328a != null) {
                try {
                    f1328a.invoke(popupWindow, new Object[]{Integer.valueOf(i)});
                } catch (Exception unused2) {
                }
            }
        }

        /* renamed from: a */
        public void mo2003a(PopupWindow popupWindow, View view, int i, int i2, int i3) {
            if ((C0402d.m1700a(i3, C0421r.m1799f(view)) & 7) == 5) {
                i -= popupWindow.getWidth() - view.getWidth();
            }
            popupWindow.showAsDropDown(view, i, i2);
        }

        /* renamed from: a */
        public void mo2004a(PopupWindow popupWindow, boolean z) {
        }
    }

    /* renamed from: a */
    public static void m2354a(PopupWindow popupWindow, int i) {
        f1326a.mo2005a(popupWindow, i);
    }

    /* renamed from: a */
    public static void m2355a(PopupWindow popupWindow, View view, int i, int i2, int i3) {
        f1326a.mo2003a(popupWindow, view, i, i2, i3);
    }

    /* renamed from: a */
    public static void m2356a(PopupWindow popupWindow, boolean z) {
        f1326a.mo2004a(popupWindow, z);
    }
}
