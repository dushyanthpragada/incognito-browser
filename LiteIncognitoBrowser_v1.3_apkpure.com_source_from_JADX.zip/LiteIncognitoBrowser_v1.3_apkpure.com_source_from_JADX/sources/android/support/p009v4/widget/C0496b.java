package android.support.p009v4.widget;

import android.support.p009v4.p017e.C0329a;

/* renamed from: android.support.v4.widget.b */
public interface C0496b {

    /* renamed from: a */
    public static final boolean f1306a = C0329a.m1460a();
}
