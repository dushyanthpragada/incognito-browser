package android.support.p009v4.widget;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: android.support.v4.widget.k */
public abstract class C0520k extends C0501d {

    /* renamed from: j */
    private int f1330j;

    /* renamed from: k */
    private int f1331k;

    /* renamed from: l */
    private LayoutInflater f1332l;

    @Deprecated
    public C0520k(Context context, int i, Cursor cursor, boolean z) {
        super(context, cursor, z);
        this.f1331k = i;
        this.f1330j = i;
        this.f1332l = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: a */
    public View mo1970a(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.f1332l.inflate(this.f1330j, viewGroup, false);
    }

    /* renamed from: b */
    public View mo1975b(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.f1332l.inflate(this.f1331k, viewGroup, false);
    }
}
